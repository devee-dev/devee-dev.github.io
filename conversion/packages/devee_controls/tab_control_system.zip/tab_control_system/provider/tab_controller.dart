import "package:flutter/material.dart";

class SelectedState extends ChangeNotifier {
  bool _isSelected = false;

  bool get isSelected => _isSelected;

  void setSelected(bool value) {
    if (_isSelected != value) {
      _isSelected = value;
      notifyListeners();
    }
  }
}

class TabContentNotifier extends ChangeNotifier {
  int _currentIndex = 0;

  int get currentIndex => _currentIndex;

  void updateIndex(int newIndex) {
    _currentIndex = newIndex;
    notifyListeners();
  }
}
