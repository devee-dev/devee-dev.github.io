import "package:custom_widgets/features/tab_control_system/widgets/tab_data.dart";
import "package:flutter/material.dart";

abstract class CustomPressable extends StatelessWidget with TabData {
  final bool pressed;

  const CustomPressable({
    super.key,
    this.pressed = false,
  });
}
