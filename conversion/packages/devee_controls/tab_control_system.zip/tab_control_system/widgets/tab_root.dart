import "package:custom_widgets/features/tab_control_system/provider/tab_controller.dart";
import "package:flutter/material.dart";
import "package:provider/provider.dart";

class TabRoot extends StatelessWidget {
  final Widget child;

  const TabRoot({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => TabContentNotifier(),
      child: child,
    );
  }
}
