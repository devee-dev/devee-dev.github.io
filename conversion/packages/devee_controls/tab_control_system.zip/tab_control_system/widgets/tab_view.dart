import "package:custom_widgets/features/tab_control_system/provider/tab_controller.dart";
import "package:flutter/material.dart";
import "package:provider/provider.dart";

class TabView extends StatefulWidget {
  final List<Widget> children;
  final Widget defaultContent;

  const TabView({
    super.key,
    required this.children,
    required this.defaultContent,
  });

  @override
  State<TabView> createState() => _TabViewState();
}

class _TabViewState extends State<TabView> {
  late PageController _pageController;

  @override
  void initState() {
    super.initState();
    _pageController = PageController();
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<TabContentNotifier>(
      builder: (context, contentNotifier, child) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (_pageController.hasClients) {
            _pageController.animateToPage(
              contentNotifier.currentIndex,
              duration: const Duration(milliseconds: 300),
              curve: Curves.easeInOut,
            );
          }
        });

        return PageView(
          controller: _pageController,
          onPageChanged: (index) {
            contentNotifier.updateIndex(index);
          },
          children: widget.children.map((child) => child ?? widget.defaultContent).toList(),
        );
      },
    );
  }
}
