import "package:custom_widgets/features/tab_control_system/provider/tab_controller.dart";
import "package:custom_widgets/features/tab_control_system/widgets/custom_tappable.dart";
import "package:custom_widgets/features/tab_control_system/widgets/pressable.dart";
import "package:flutter/material.dart";
import "package:provider/provider.dart";

class CustomTabBar extends StatefulWidget {
  final List<CustomPressable> tabs;
  final TabController? controller;
  final TabAlignment? tabAlignment;
  final Widget? indicator;
  final bool underneath;
  final Function(int)? onTap;
  final bool isScrollable;

  const CustomTabBar({
    super.key,
    required this.tabs,
    this.controller,
    this.tabAlignment,
    this.indicator,
    this.underneath = false,
    this.onTap,
    this.isScrollable = false,
  });

  @override
  State<CustomTabBar> createState() => _CustomTabBarState();
}

class _CustomTabBarState extends State<CustomTabBar> with SingleTickerProviderStateMixin {
  late TabController _controller;
  late List<SelectedState> _tabStates;

  @override
  void initState() {
    super.initState();
    _controller = widget.controller ?? TabController(length: widget.tabs.length, vsync: this);
    _controller.addListener(_handleTabSelection);
    _tabStates = List.generate(widget.tabs.length, (_) => SelectedState());
    _updateSelectedStates();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _updateTabController();
  }

  @override
  void didUpdateWidget(CustomTabBar oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.controller != oldWidget.controller) {
      _updateTabController();
    }
    if (widget.tabs.length != oldWidget.tabs.length) {
      _tabStates = List.generate(widget.tabs.length, (_) => SelectedState());
      _updateSelectedStates();
    }
  }

  @override
  void dispose() {
    _controller.removeListener(_handleTabSelection);
    if (widget.controller == null) {
      _controller.dispose();
    }
    super.dispose();
  }

  void _updateTabController() {
    final TabController newController = widget.controller ?? DefaultTabController.of(context);
    if (newController != _controller) {
      _controller.removeListener(_handleTabSelection);
      _controller = newController;
      _controller.addListener(_handleTabSelection);
      _updateSelectedStates();
    }
  }

  void _handleTabSelection() {
    if (_controller.indexIsChanging) {
      _updateSelectedStates();
      _updateContent(_controller.index);
    }
  }

  void _updateSelectedStates() {
    for (int i = 0; i < _tabStates.length; i++) {
      _tabStates[i].setSelected(i == _controller.index);
    }
  }

  void _updateContent(int index) {
    final contentNotifier = Provider.of<TabContentNotifier>(context, listen: false);
    contentNotifier.updateIndex(index);
  }

  void _onTabTap(int index) {
    _controller.animateTo(index);
    widget.onTap?.call(index);
    _updateContent(index);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (widget.underneath && widget.indicator != null) _buildIndicator(),
        _buildTabRow(),
        if (!widget.underneath && widget.indicator != null) _buildIndicator(),
      ],
    );
  }

  Widget _buildTabRow() {
    Widget tabRow;

    if (widget.isScrollable) {
      tabRow = SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: List.generate(widget.tabs.length, (index) {
            return _buildTabButton(index);
          }),
        ),
      );

      if (widget.tabAlignment == TabAlignment.start) {
        return Align(
          alignment: Alignment.centerLeft,
          child: tabRow,
        );
      } else if (widget.tabAlignment == TabAlignment.startOffset) {
        return Padding(
          padding: const EdgeInsets.only(left: 52.0),
          child: tabRow,
        );
      }
    } else {
      if (widget.tabAlignment == TabAlignment.fill) {
        tabRow = Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: List.generate(widget.tabs.length, (index) {
            return Expanded(child: _buildTabButton(index));
          }),
        );
      } else {
        tabRow = Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(widget.tabs.length, (index) {
            return _buildTabButton(index);
          }),
        );
      }
    }
    return tabRow;
  }

  Widget _buildTabButton(int index) {
    return ChangeNotifierProvider.value(
      value: _tabStates[index],
      child: Builder(
        builder: (context) {
          final tab = widget.tabs[index];

          if (tab is CustomTappable) {
            return GestureDetector(
              onTap: () {
                (tab as CustomTappable).onTap();
                _onTabTap(index);
              },
              child: tab,
            );
          } else {
            return InkWell(
              onTap: () => _onTabTap(index),
              splashColor: Theme.of(context).splashColor,
              highlightColor: Theme.of(context).highlightColor,
              child: tab,
            );
          }
        },
      ),
    );
  }

  Widget _buildIndicator() {
    return AnimatedBuilder(
      animation: _controller.animation!,
      builder: (context, child) {
        return FractionallySizedBox(
          widthFactor: 1 / widget.tabs.length,
          alignment: Alignment(
            _controller.animation!.value * 2 - 1,
            0,
          ),
          child: widget.indicator,
        );
      },
    );
  }
}
