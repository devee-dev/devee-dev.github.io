import "package:flutter/material.dart";

mixin TabData {
  Widget? get tabContent;
}
