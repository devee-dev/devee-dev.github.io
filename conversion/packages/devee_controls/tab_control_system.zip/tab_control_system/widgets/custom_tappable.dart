abstract class CustomTappable {
  void onTap();
}
