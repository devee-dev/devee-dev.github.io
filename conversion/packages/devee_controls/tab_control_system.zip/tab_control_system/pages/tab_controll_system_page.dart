import "package:custom_widgets/features/tab_control_system/provider/tab_controller.dart";
import "package:custom_widgets/features/tab_control_system/widgets/custom_tappable.dart";
import "package:custom_widgets/features/tab_control_system/widgets/pressable.dart";
import "package:custom_widgets/features/tab_control_system/widgets/tab_bar.dart";
import "package:custom_widgets/features/tab_control_system/widgets/tab_root.dart";
import "package:custom_widgets/features/tab_control_system/widgets/tab_view.dart";
import "package:flutter/material.dart";
import "package:provider/provider.dart";

class MyTab extends CustomPressable implements CustomTappable {
  final String text;
  final Widget? content;

  const MyTab({
    super.key,
    required this.text,
    this.content,
  });

  @override
  Widget build(BuildContext context) {
    return Consumer<SelectedState>(
      builder: (context, selectedState, child) {
        final isSelected = selectedState.isSelected;
        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
          child: Text(
            text,
            style: TextStyle(
              fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
              color: isSelected ? Colors.blue : Colors.black,
            ),
          ),
        );
      },
    );
  }

  @override
  Widget? get tabContent => content;

  @override
  void onTap() {
    debugPrint("Tab $text tapped");
  }
}

class MyTabPressable extends CustomPressable {
  final String text;
  final Widget? content;

  const MyTabPressable({
    super.key,
    required this.text,
    this.content,
  });

  @override
  Widget build(BuildContext context) {
    final isSelected = context.select((SelectedState s) => s.isSelected);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      child: Text(
        text,
        style: TextStyle(
          fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
          color: isSelected ? Colors.blue : Colors.black,
        ),
      ),
    );
  }

  @override
  Widget? get tabContent => content;
}

class TabBarSystemPage extends StatelessWidget {
  const TabBarSystemPage({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return const DefaultTabController(
      length: 3,
      child: Scaffold(
        body: TabRoot(
          child: Column(
            children: [
              CustomTabBar(
                tabs: [
                  MyTab(text: "Tab 1"),
                  MyTab(text: "Tab 2"),
                  MyTabPressable(text: "Tab 3"),
                ],
                indicator: SizedBox(height: 2, child: ColoredBox(color: Colors.blue)),
                underneath: true,
              ),
              Expanded(
                child: TabView(
                  defaultContent: Text("Default content"),
                  children: [
                    Text("Content for Tab 1"),
                    Text("Content for Tab 2"),
                    Text("Content for Tab 3"),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
